//
//  LocationsData.swift
//
//  Created by Abdulrahman Al Shathry on 15/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//


import Foundation

struct LocationsData {
    var studentLocations: [StudentLocation] = []
}
